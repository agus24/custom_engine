class item:
    def __init__(self, mpw=0, defend=0, mspd=0, hp=0, dmg=0):
        self.mpw = mpw
        self.defend = defend
        self.mspd = mspd
        self.hp = hp
        self.dmg = dmg