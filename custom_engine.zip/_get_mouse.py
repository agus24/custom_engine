import pyautogui

print(pyautogui.position())

slot = [300, 120]
output = []
for i in range(0, 8):
    new_slot = slot
    slot[0] = 300 + 30 * i
    output.append(slot)

print(output)
