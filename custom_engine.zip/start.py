from mouseSeal import MouseSeal
from time import sleep
import pyautogui
import keyboard
import pywinauto
from constants import *
from pointers import *

mouse = MouseSeal()
k = pywinauto.keyboard
start_addr = mouse.getPointer(INVENTORY['base'], INVENTORY['offset'])
freeze_dialog = 0x6F1FFC
global_delay = 0.5
mouse_delay = 0.2
g13_value = 5371
start = True
jibit_status = False

sell_equipment = True
sell_qty = 290
exclude_item = True
excluded_item_id = [5371, 434, 432, 433, 3981, 10942, 5477, 5478, 10447]
always_sell = [3982, 3983, 3984, 3985, 3986, 3987, 3988, 6834, 6835, 6836, 6837, 6838, 6839, 6840, 95, 96, 112, 115, 3652, 3653]
jumlah_slot = 28
maximum_grade = 2

def disableDialog():
    mouse.setAddressIntValue(freeze_dialog, 0)

def getInventory():
    inventory = []
    addr = start_addr
    print(mouse.getAddressIntValue(addr))
    for i in range(0, jumlah_slot):
        data = {
            "slot" : i + 1,
            "address": hex(addr),
            "qty" : mouse.getAddressIntValue(addr),
            "item_id": mouse.getAddressIntValue(addr - 0xC),
            "grade": mouse.getAddressIntValue(addr - 0x8),
        }
        addr += 0x74

        inventory.append(data)
    return inventory


def check_item():
    inventories = getInventory()
    sell_slot = []
    for inven in inventories:
        if inven['item_id'] not in excluded_item_id:
            if sell_equipment:
                equipment = inven['qty'] > sell_qty or (inven['qty'] == 0 and inven["grade"] <= maximum_grade)
            else:
                equipment = inven['qty'] > sell_qty

            if inven['item_id'] != 0 and equipment:
                sell_slot.append(inven['slot'])

        if inven['item_id'] in always_sell:
            sell_slot.append(inven['slot'])

    return sell_slot

def start_macro():
    global jibit_status
    sellable_items = check_item()
    if len(sellable_items) > 0:
        k.send_keys("^q")
        jibit_status = False
        sleep(global_delay)
        sell_item(sellable_items)
    elif check_potion():
        k.send_keys("^q")
        jibit_status = False
        sleep(global_delay)
        buy_potion()
    else:
        if not jibit_status:
            jibit_status = True
            # k.send_keys("^p")
        # sleep(30)
        hunt()

def start_jibit():
    k.send_keys("^p}")

def hunt():
    click(delay=0)
    move(395, 318, delay=0.05)
    k.send_keys(
        "{q down}"
        "{q up}"
    )
    sleep(0.05)
    k.send_keys("{F1 down}")
    k.send_keys("{F2 down}")
    k.send_keys("{F3 down}")
    k.send_keys("{F1 up}")
    k.send_keys("{F2 up}")
    k.send_keys("{F3 up}")
    k.send_keys("{F5 down}")
    k.send_keys("{F5 up}")
    disableDialog()
    k.send_keys("{SPACE down}")
    k.send_keys("{SPACE up}")
    sleep(global_delay)
    k.send_keys("{SPACE down}")
    k.send_keys("{SPACE up}")
    sleep(global_delay)
    k.send_keys("{SPACE down}")
    k.send_keys("{SPACE up}")
    sleep(global_delay)
    print("step")

def sell_item(slots):
    print(slots)
    click(SHOP[0], SHOP[1])
    sleep(global_delay)
    click(SHOP_CONFIRMATION[0], SHOP_CONFIRMATION[1])
    sleep(mouse_delay)
    for slot in slots:
        move(SHOP_SLOT[slot][0], SHOP_SLOT[slot][1])
        mouse_down()
        move(SHOP_FIELD[0], SHOP_FIELD[1])
        mouse_up()
        click(BUTTON_NUMBER[2][0], BUTTON_NUMBER[2][1])
        click(BUTTON_NUMBER[4][0], BUTTON_NUMBER[4][1])
        click(BUTTON_NUMBER[4][0], BUTTON_NUMBER[4][1])
        click(OK_BUTTON[0], OK_BUTTON[1])
        click(SHOP_CONFIRMATION[0], SHOP_CONFIRMATION[1])

    close_shop()

def buy_potion():
    click(SHOP[0], SHOP[1])
    sleep(global_delay)
    click(SHOP_CONFIRMATION[0], SHOP_CONFIRMATION[1])
    sleep(mouse_delay)
    move(MAX_RED_POTION[0], MAX_RED_POTION[1])
    mouse_down()
    move(INVENTORY_FIELD[0], INVENTORY_FIELD[1])
    mouse_up()
    click(MAX_BUTTON[0], MAX_BUTTON[1])
    click(OK_BUTTON[0], OK_BUTTON[1])
    click(SHOP_CONFIRMATION[0], SHOP_CONFIRMATION[1])

    move(HIGH_BLUE_POTION[0], HIGH_BLUE_POTION[1])
    mouse_down()
    move(INVENTORY_FIELD[0], INVENTORY_FIELD[1])
    mouse_up()
    click(MAX_BUTTON[0], MAX_BUTTON[1])
    click(OK_BUTTON[0], OK_BUTTON[1])
    click(SHOP_CONFIRMATION[0], SHOP_CONFIRMATION[1])
    sleep(mouse_delay)

    close_shop()

def check_potion():
    inventory = []
    addr = start_addr
    for i in range(0, 40):
        data = {
            "slot" : i + 1,
            "address": addr,
            "qty" : mouse.getAddressIntValue(addr),
            "item_id": mouse.getAddressIntValue(addr - 0xC),
        }
        addr += 0x74

        inventory.append(data)
    if inventory[32]['qty'] < 70 or inventory[33]['qty'] < 70:
        return True
    return False

def click(x=0, y=0, delay=mouse_delay):
    if x and y:
        move(x, y)
    sleep(delay)
    pyautogui.mouseDown()
    pyautogui.mouseUp()
    sleep(delay)

def move(x, y, delay=mouse_delay):
    pyautogui.moveTo(x, y)
    sleep(delay)

def mouse_down():
    pyautogui.mouseDown()

def mouse_up():
    pyautogui.mouseUp()

def close_shop():
    click(261, 83)
    move(395, 318)

print("Start")
# print(getInventory())
while True:
    if keyboard.is_pressed('-') :
        while start:
            start_macro()
            if keyboard.is_pressed('c') :
                print('stopping.')
                k.send_keys("^q")
                jibit_status = False
                break
        sleep(mouse_delay)

    if keyboard.is_pressed("="):
        print(getInventory()[0])
        print(check_item())
        sleep(0.2)
