import subprocess
import win32gui
import time

# proc = subprocess.Popen(["C:\\Program Files\\Cheat Engine 7.0\\Cheat Engine.exe"])

def startProgram():
    SW_HIDE = 0
    info = subprocess.STARTUPINFO()
    info.dwFlags = subprocess.STARTF_USESHOWWINDOW
    info.wShowWindow = SW_HIDE
    subprocess.Popen(r'C:\\Program Files\\Cheat Engine 7.0\\Cheat Engine.exe', startupinfo=info)
startProgram()
