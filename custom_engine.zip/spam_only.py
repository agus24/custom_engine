from mouseSeal import MouseSeal
from pointers import *
import keyboard
from time import sleep


mouse = MouseSeal()
skill_addr = mouse.getPointer(SKILL['base'], SKILL['offset'])
job_addr = mouse.getPointer(JOB['base'], JOB['offset'])
skill_set = mouse.getPointer(SKILL_SET['base'], SKILL_SET['offset'])
lari_addr = mouse.getPointer(LARI['base'], LARI['offset'])
monster_addr = mouse.getPointer(MONSTER['base'], MONSTER['offset'])

print(lari_addr)
base_mspd = mouse.getAddressIntValue(lari_addr)
mspd_state = False

def do_skill():
    mouse.setAddressIntValue(skill_addr, 3)

while True:
    if keyboard.is_pressed('-') :
        while True:
            mouse.setAddressIntValue(monster_addr, -1)
            mouse.setAddressIntValue(skill_set, 251)
            mouse.setAddressIntValue(skill_addr, 3)
            sleep(0.5)
            mouse.setAddressIntValue(skill_set, 202)
            mouse.setAddressIntValue(skill_addr, 3)
            sleep(0.5)
            mouse.setAddressIntValue(skill_set, 201)
            mouse.setAddressIntValue(skill_addr, 3)
            sleep(2.5)

    if keyboard.is_pressed("`"):
        while True:
            mouse.setAddressIntValue(monster_addr, -1)
            mouse.setAddressIntValue(skill_set, 65)
            mouse.setAddressIntValue(skill_addr, 3)
            sleep(0.5)
            mouse.setAddressIntValue(skill_set, 157)
            mouse.setAddressIntValue(skill_addr, 3)
            sleep(0.5)
            mouse.setAddressIntValue(skill_set, 155)
            mouse.setAddressIntValue(skill_addr, 3)
            sleep(0.5)
            mouse.setAddressIntValue(skill_set, 52)
            mouse.setAddressIntValue(skill_addr, 3)
            sleep(0.5)

    if keyboard.is_pressed("="):
        change_job = int(input("change job to : "))
        mouse.setAddressIntValue(job_addr, change_job)
        sleep(0.2)

    if keyboard.is_pressed("]"):
        mouse.setAddressIntValue(skill_addr, 0)
        print(mouse.getAddressIntValue(skill_set))
        sleep(0.2)

    if keyboard.is_pressed("/"):
        if not mspd_state:
            mspd_state = True
            mouse.setAddressIntValue(lari_addr, 500)
        else:
            mspd_state = False
            mouse.setAddressIntValue(lari_addr, 0)

        sleep(0.2)
