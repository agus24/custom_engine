from mouseSeal import MouseSeal
from pointers import *
import keyboard
from time import sleep

mouse = MouseSeal()
skill_addr = mouse.getPointer(SKILL['base'], SKILL['offset'])
job_addr = mouse.getPointer(JOB['base'], JOB['offset'])
skill_set = mouse.getPointer(SKILL_SET['base'], SKILL_SET['offset'])

# skill_list = [157, 202, 150, 185, 158, 159, 34, 30, 165, 164, 32, 29, 145, 43, 198, 141, 82, 183, 60, 18, 214, 215, 37, 152, 35, 248, 251]
skill_list = [201, 202, 157, 150, 165, 133, 185, 198, 200, 199, 158, 159, 145, 183, 164, 152, 221, 34, 29, 248, 251, 60, 25, 132, 30, 34, 43, 29, 32]

def do_skill():
    mouse.setAddressIntValue(skill_addr, 3)

def start():
    for skill in skill_list:
        mouse.setAddressIntValue(skill_set, skill)
        sleep(0.05)
        do_skill()
        sleep(0.05)

while True:
    if keyboard.is_pressed('-'):
        start()
        sleep(0.2)

    if keyboard.is_pressed("="):
        print(mouse.getAddressIntValue(skill_set))
        sleep(0.5)

    if keyboard.is_pressed("]"):
        change_job = int(input("change job to : "))
        mouse.setAddressIntValue(job_addr, change_job)
        sleep(0.2)

