from mouseSeal import MouseSeal
from time import sleep
import pyautogui
import keyboard
import pywinauto
from constants import *
from pointers import *

mouse = MouseSeal()
k = pywinauto.keyboard
start_addr = mouse.getPointer(INVENTORY['base'], INVENTORY['offset'])
combo_1 = mouse.getPointer(COMBO_1['base'], COMBO_1['offset'])
combo_2 = mouse.getPointer(COMBO_2['base'], COMBO_2['offset'])
spam = mouse.getPointer(SPAM['base'], SPAM['offset'])
lari_addr = mouse.getPointer(LARI['base'], LARI['offset'])

mspd_state = False

while True:
    if keyboard.is_pressed("-"):
        start = True
        print("started")
        while start:
            mouse.setAddressIntValue(combo_1, 6)
            mouse.setAddressIntValue(combo_2, 3008)
            k.send_keys("{a up}")
            k.send_keys("{a down}")
            mouse.setAddressIntValue(spam, 0)
            sleep(0.0001)
            if keyboard.is_pressed("c"):
                start = False
                print("stopped")

    if keyboard.is_pressed("/"):
        if not mspd_state:
            mspd_state = True
            mouse.setAddressIntValue(lari_addr, 310)
        else:
            mspd_state = False
            mouse.setAddressIntValue(lari_addr, 0)

        sleep(0.2)
