
from mouseSeal import MouseSeal
from pointers import *
import keyboard
from time import sleep


# mouse = MouseSeal()
string = "Hayoo"

# mouse.setAddressStringValue(0x161C2B30, string)
