from mouseSeal import MouseSeal
from time import sleep
import keyboard

addr = 0x006F1FFC
mouse = MouseSeal()

while True:
    if keyboard.is_pressed("-"):
        mouse.assemble()
        sleep(0.2)
