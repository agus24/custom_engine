from mouseSeal import MouseSeal
from time import sleep
from pointers import *
import keyboard
import pyautogui
import pywinauto
from constants import *

mouse = MouseSeal()

global_delay = 0.5
mouse_delay = 0.2
k = pywinauto.keyboard
skill_addr = mouse.getPointer(SKILL['base'], SKILL['offset'])
monster_addr = mouse.getPointer(MONSTER['base'], MONSTER['offset'])
inven_addr = mouse.getPointer(INVENTORY['base'], INVENTORY['offset'])
target_addr = 0x011AC388  # address target panah
target = [7383, 7384, 7397, 7375, 7403, 7405, 7412, 7379, 7400, 7381, 7394]
# target = [7426, 7424, 7418, 7419, 7416, 7412]
# target = [7439, 7430, 7431, 7436, 7428, 7434]
target_index = 0
inventory = []
print(skill_addr)

def next_target():
    global target_index
    target_index += 1
    if target_index >= len(target):
        target_index = 0
    print(target[target_index])

def getInventory():
    inventory = []
    addr = inven_addr
    print(mouse.getAddressIntValue(addr))
    for i in range(0, 20):
        data = {
            "slot" : i + 1,
            "address": addr,
            "qty" : mouse.getAddressIntValue(addr),
            "item_id": mouse.getAddressIntValue(addr - 0xC),
        }
        addr += 0x74

        inventory.append(data)
    return inventory

def check_item():
    inventories = getInventory()
    sell_slot = []
    for inven in inventories:
        if inven['item_id'] != 5371:
            if inven['item_id'] != 0 and (inven['qty'] > 250 or inven['qty'] == 0):
                sell_slot.append(inven['slot'])

    return sell_slot

def sell_item(slots):
    print(slots)
    click(SHOP[0], SHOP[1])
    sleep(global_delay)
    click(SHOP_CONFIRMATION[0], SHOP_CONFIRMATION[1])
    sleep(mouse_delay)
    for slot in slots:
        move(SHOP_SLOT[slot][0], SHOP_SLOT[slot][1])
        mouse_down()
        move(SHOP_FIELD[0], SHOP_FIELD[1])
        mouse_up()
        click(BUTTON_NUMBER[2][0], BUTTON_NUMBER[2][1])
        click(BUTTON_NUMBER[4][0], BUTTON_NUMBER[4][1])
        click(BUTTON_NUMBER[4][0], BUTTON_NUMBER[4][1])
        click(OK_BUTTON[0], OK_BUTTON[1])
        click(SHOP_CONFIRMATION[0], SHOP_CONFIRMATION[1])

    close_shop()

def click(x=0, y=0, delay=mouse_delay):
    if x and y:
        move(x, y)
    sleep(delay)
    pyautogui.mouseDown()
    pyautogui.mouseUp()
    sleep(delay)

def move(x, y, delay=mouse_delay):
    pyautogui.moveTo(x, y)
    sleep(delay)

def mouse_down():
    pyautogui.mouseDown()

def mouse_up():
    pyautogui.mouseUp()

def close_shop():
    click(261, 83)
    move(395, 318)

def run_getok():
    sellable_items = check_item()
    if len(sellable_items) > 0:
        print("sell item")
        sell_item(sellable_items)
    else:
        for i in range(0, 50):
            mouse.setAddressIntValue(monster_addr, target[target_index])
            sleep(0.05)
            mouse.setAddressIntValue(target_addr, target[target_index])
            sleep(0.05)
            mouse.setAddressIntValue(skill_addr, 3)
            sleep(0.05)
            next_target()

    pick_item()


def pick_item():
    print("picking item")
    for i in range(0, 10):
        k.send_keys('{SPACE}')
        k.send_keys('{SPACE}')
        k.send_keys('{SPACE}')
        k.send_keys('{SPACE}')
        sleep(0.5)


while True:
    if keyboard.is_pressed("-"):
        while True:
            run_getok()
            for i in range(0, 10):
                print(f"wait {i}")
                sleep(1)

    if keyboard.is_pressed("="):
        mouse.setAddressIntValue(skill_addr, 0)
        sleep(0.2)

    if keyboard.is_pressed("["):
        mouse.setAddressIntValue(skill_addr, 3)
        sleep(0.2)
