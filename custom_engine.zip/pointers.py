SKILL = {
    "base": 0x2FDE3C,
    "offset": 0x02308
}

SKILL_SET = {
    "base": 0x2FDE3C,
    "offset": 0x02304
}

INVENTORY = {
    "base": 0x2FCBC0,
    "offset": 0x5F0
}

MONSTER = {
    "base": 0x2FDE3C,
    "offset": 0x1678
}

FREEZE_DIALOG = {
    "base": 0x2F1FFC,
    "offset": 0x0
}

JOB = {
    "base": 0x2FDE3C,
    "offset": 0xB3C
}

SELIP = {
    "base": 0x30ACE8,
    "offset": 0x0
}

KETUA_PT = {
    "base": 0x30A87C,
    "offset": 0x0
}

JUMLAH_PT = {
    "base": 0x30A8A0,
    "offset": 0x0
}

MAP = {
    "base": 0x2F1FEC,
    "offset": 0x0
}

DART = {
    "base": 0x2FDE3C,
    "offset": 0x1798
}

SPAM = {
    "base": 0x2FDE3C,
    "offset": 0x11B0
}

COMBO_1 = {
    "base": 0x2FDE3C,
    "offset": 0x11BC
}

COMBO_2 = {
    "base": 0x2FDE3C,
    "offset": 0x11C0
}

LARI = {
    "base": 0x2FCBC0,
    "offset": 0x1D8C
}

# combo
# SO3DPlus.exe+2F99D8 + 3784
# SO3DPlus.exe+2FDE3C + 11B0
# combo 11BC 11C0

# 9F 00 00 00 00 00 00 FF 01 00 00 00 00 00 00 00 05 00 00 00 20 03 00 00
# offset 14
# 78FB094
