from mouseSeal import MouseSeal
from pointers import *
import keyboard
from time import sleep

mouse = MouseSeal()
skill_addr = mouse.getPointer(SKILL['base'], SKILL['offset'])
job_addr = mouse.getPointer(JOB['base'], JOB['offset'])
skill_set = mouse.getPointer(SKILL_SET['base'], SKILL_SET['offset'])

skill_list = [29, 141, 32, 248, 251, 216, 215, 214, 37, 142]  # tambahin skillnya di sini

def do_skill():
    mouse.setAddressIntValue(skill_addr, 3)

def start():
    for skill in skill_list:
        mouse.setAddressIntValue(skill_set, skill)
        sleep(0.05)
        do_skill()
        sleep(0.05)

while True:
    if keyboard.is_pressed('-') :
        start()
        sleep(0.2)

