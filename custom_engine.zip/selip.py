from mouseSeal import MouseSeal
from pointers import *
import keyboard
from time import sleep


mouse = MouseSeal()
selip_addr = 0x400000 + SELIP['base']

name = input("nama char yang mau di selip ? ") or ""
mouse.setAddressStringValue(selip_addr, str.encode(name))

for i in range(len(name), 16):
    mouse.setAddressIntValue(selip_addr + i, 0)
