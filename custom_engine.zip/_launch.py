import engine.scan
from mouseSeal import MouseSeal


scanner = engine.scan.Scan(MouseSeal())

scanner.scan4Bytes(input("scan 4 bytes : "))
