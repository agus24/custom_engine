import win32process
import win32api
import pymem
import helper
import sys
import time
import itemStatus

class MouseSeal :
    pm = False
    process = False
    pid = False
    pc = False
    pointerStat = False

    def __init__(self) :
        self.pm = pymem.Pymem()
        self.process = self.getProcess()
        self.pid = self.process.th32ProcessID
        self.pc = pymem.process.open(self.pid)

        pid = int(input("Change PID ? (default = Seal Pertama yg di buka) : ") or 0)
        self.setPid(pid)

        self.baseAddressStat = int(0x400000) + int(0x003DA400)
        self.pointerStat = pymem.memory.read_int(self.pc, self.baseAddressStat)

    def getProcess(self) :
        processes = pymem.process.list_processes()
        for value in processes:
            if value.szExeFile == b'SO3DPlus.exe':
                return value
            pass

    def getPid(self) :
        return self.pid

    def setPid(self, new_pid) :
        default_pid = self.pid
        if new_pid != 0 :
            default_pid = new_pid
        print(default_pid)
        self.pc = pymem.process.open(default_pid)

    def changeMovementSpeed(self, value) :
        addr1 = self.pointerStat + int(0x1b9c)
        addr2 = self.pointerStat + int(0x1bac)
        pymem.memory.write_int(self.pc, addr1, value)
        pymem.memory.write_int(self.pc, addr2, value)

    def readAddress(self, address) :
        return pymem.memory.read_int(self.pc, address)

    def changeValue(self, address, value) :
        pymem.memory.write_int(self.pc, address, value)

    def moveMouse(self, x, y) :
        baseAddressMouse = int(0x400000) + int(0x00DD5F24)
        pointerMouse = pymem.memory.read_int(self.pc, baseAddressMouse)
        mouseX = (pointerMouse) + int(0x2c0)
        mouseY = (pointerMouse) + int(0x2c4)
        pymem.memory.write_short(self.pc, mouseX, x)
        pymem.memory.write_short(self.pc, mouseY, y)

    def getPosition(self) :
        baseAddressMouse = int(0x400000) + int(0x00DD5F24)
        pointerMouse = pymem.memory.read_int(self.pc, baseAddressMouse)
        mouseX = (pointerMouse) + int(0x2c0)
        mouseY = (pointerMouse) + int(0x2c4)
        pos = [pymem.memory.read_short(self.pc, mouseX), pymem.memory.read_short(self.pc, mouseY)]
        print(pos)

    def getStatList(self) :
        mpw = (self.pointerStat) + int(0x450)
        defend = (self.pointerStat) + int(0x454)
        mspd = (self.pointerStat) + int(0x468)
        hp = (self.pointerStat) + int(0x46c)

        print("mpw : " + str(pymem.memory.read_short(self.pc, mpw)))
        print("defend : " + str(pymem.memory.read_short(self.pc, defend)))
        print("mspd : " + str(pymem.memory.read_short(self.pc, mspd)))
        print("hp : " + str(pymem.memory.read_short(self.pc, hp)))

    def makeStatHp(self, value) :
        print("hp : "+value)

    def getItemQty(self) :
        slot_1 = (self.pointerStat) + 1056
        slot_2 = (self.pointerStat) + 1056 + 116
        slot_3 = (self.pointerStat) + 1056 + 116 + 116
        slot_4 = (self.pointerStat) + 1056 + 116 + 116 + 116
        slot_5 = (self.pointerStat) + 1056 + 116 + 116 + 116 + 116

        sys.stdout.write(
            "slot : " + str(pymem.memory.read_short(self.pc, slot_1)) +
            "  slot : " + str(pymem.memory.read_short(self.pc, slot_2)) +
            "  slot : " + str(pymem.memory.read_short(self.pc, slot_3)) +
            "  slot : " + str(pymem.memory.read_short(self.pc, slot_4)) +
            "  slot : " + str(pymem.memory.read_short(self.pc, slot_5)) + "\r"
        )
        sys.stdout.flush()
        # print("slot : 300")

    def getItemValue(self) :
        slot = []
        item = []
        for i in range(0, 40) :
            calc = (self.pointerStat) + 1056 + (116*i)
            slot.append(calc)
            item.append(pymem.memory.read_short(self.pc, calc))
        return item

    def getUserId(self) :
        baseAddr = int(0x400000) + int(0x003DB34C)
        pointer = pymem.memory.read_int(self.pc, baseAddr)
        idAddress = pointer + int(0x1268)
        return  pymem.memory.read_string(self.pc, idAddress, 16)

    def spamSkill(self) :
        baseAddr = int(0x400000) + int(0x003DB34C)
        pointer = pymem.memory.read_int(self.pc, baseAddr)
        spamAddr = pointer + int(0x1D00)
        val = pymem.memory.write_int(self.pc, spamAddr, 3)

    def checkHP(self) :
        offset = int(0xE04)
        baseAddr = int(0x400000) + int(0x003DB34C)
        pointer = pymem.memory.read_int(self.pc, baseAddr)
        hpAddr = pointer + offset
        return pymem.memory.read_short(self.pc, hpAddr)

    def setSkill(self, skillValue) :
        baseAddr = int(0x400000) + int(0x003DB34C)
        pointer = pymem.memory.read_int(self.pc, baseAddr)
        skillAddr = pointer + int(0x1CFC)
        val = pymem.memory.write_int(self.pc, skillAddr, skillValue)

    def getSkill(self) :
        baseAddr = int(0x400000) + int(0x003DB34C)
        pointer = pymem.memory.read_int(self.pc, baseAddr)
        skillAddr = pointer + int(0x1CFC)
        return pymem.memory.read_int(self.pc, skillAddr)

    def doSkill(self, skillValue, delay=1) :
        self.setSkill(skillValue)
        self.spamSkill()
        time.sleep(delay)

    def runSkill(self, skillValue) :
        setSkill(skillValue)
        self.spamSkill()
        time.sleep(1)
        baseAddr = int(0x400000) + int(0x003DB34C)
        pointer = pymem.memory.read_int(self.pc, baseAddr)
        spamAddr = pointer + int(0x1D00)
        val = pymem.memory.write_int(self.pc, spamAddr, 7)

    def getItemStatus(self) :
        mpw = (self.pointerStat) + int(0x450)
        defend = (self.pointerStat) + int(0x454)
        mspd = (self.pointerStat) + int(0x468)
        hp = (self.pointerStat) + int(0x46c)
        dmg = (self.pointerStat) + int(0x44c)

        status = itemStatus.item(
            mpw = pymem.memory.read_short(self.pc, mpw),
            defend = pymem.memory.read_short(self.pc, defend),
            mspd = pymem.memory.read_short(self.pc, mspd),
            hp = pymem.memory.read_short(self.pc, hp),
            dmg = pymem.memory.read_short(self.pc, dmg),
        )
        return status

    def setTarget(self, target) :
        baseAddr = int(0x400000) + int(0x00DE3250)
        pymem.memory.write_int(self.pc, baseAddr, target)
        addr = int(0x400000) + int(0x003DB34C)
        pointer = pymem.memory.read_int(self.pc, addr)
        addr = pointer + int(0x1260)
        pymem.memory.write_int(self.pc, addr, target)

    def getCurrentTarget(self) :
        baseAddr = int(0x400000) + int(0x3DB34C)
        pointer = pymem.memory.read_int(self.pc, baseAddr)
        addr = pointer + int(0x1260)
        return pymem.memory.read_int(self.pc, addr)

    def changeMoveSpeed(self, mspd) :
        baseAddr = int(0x400000) + int(0x003DA400)
        pointer = pymem.memory.read_int(self.pc, baseAddr)
        addr = pointer + int(0x1BAC)
        pymem.memory.write_int(self.pc, addr, mspd)

    def changeAp(self, ap) :
        baseAddr = int(0x400000) + int(0x3DA400)
        pointer = pymem.memory.read_int(self.pc, baseAddr)
        addr = pointer + int(0x1BB4)
        pymem.memory.write_short(self.pc, addr, ap)

    def getModuleList(self):
        return {
            "modules": list(pymem.process.list_process_modules(self.pid)),
            "threads": list(pymem.process.list_process_thread(self.pid))
        }

    def getPointer(self, ptr, offset=0x0):
        baseAddr = int(0x400000) + int(ptr)
        pointer = pymem.memory.read_int(self.pc, baseAddr)
        return pointer + int(offset)

    def getAddress(self, pointer, offset):
        return pointer + offset

    def getStringAddress(self, pointer, offset):
        return pointer + offset

    def getAddressIntValue(self, address):
        return pymem.memory.read_int(self.pc, address)

    def getAddressStringValue(self, address):
        return pymem.memory.read_string(self.pc, address)

    def setAddressIntValue(self, address, value):
        pymem.memory.write_int(self.pc, address, value)

    def setAddressStringValue(self, address, value):
        pymem.memory.write_string(self.pc, address, value)

    def assemble(self, address=None, memory=None):
        self.pm.assemble(address, memory)
