class Scan:
    result = {}
    mem_range = [0x400000, 0x0100000]

    def __init__(self, mem_reader):
        self.mem_reader = mem_reader


    def scan4Bytes(self, value):
        for address in (int(self.mem_range[0]), int(self.mem_range[1])):
            if self.mem_reader.getAddressIntValue(address) == value:
                self.result.append([address, value])
