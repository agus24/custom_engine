from mouseSeal import MouseSeal
from time import sleep
import pyautogui
import keyboard
import pywinauto
from constants import *
from pointers import *

mouse = MouseSeal()
spam = mouse.getPointer(SPAM['base'], SPAM['offset'])

while True:
    mouse.setAddressIntValue(spam, 0)
    sleep(0.001)
