import win32api

def mbox(text) :
    return win32api.MessageBox(0, text, 'title')

