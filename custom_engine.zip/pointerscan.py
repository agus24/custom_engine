from mouseSeal import MouseSeal
import keyboard
import json

mouse = MouseSeal()

start_addr = 0x400000
end_addr = 0x1000000
output = []
choice = 0


def first_scan(start, end, step=4):
    output = []
    for addr in range(start, end, step):
        print(hex(addr))
        value = mouse.getAddressIntValue(addr)
        if value >= int(0x19E50000) and value <= int(0x19E60000):
            offset = hex(int(0x19E5EB5C) - value)
            print(hex(addr), hex(value), offset)
            output.append({"addr": hex(addr), "value": hex(value), "offset": offset})

    return output

def second_scan(start, end, step=4):
    for addr in range(start, end, step):
        print(hex(addr))
        value = mouse.getAddressIntValue(addr)
        if value >= int(0x19DC0000) and value <= int(0x19DD0000):
            offset = hex(int(0x19DCCAB4) - value)
            print(hex(addr), hex(value), offset)
            output.append({"addr": hex(addr), "value": hex(value), "offset": offset})

def write_file(output):
    with open("pointer_scan.txt", "a") as f:
        f.write(json.dumps(output))
        f.close()

def next_pointer_scan():
    addrs = [{"addr": 0x4852e4, "value": 0x19dcd4e8, "offset": -0xa34}, {"addr": 0x48537c, "value": 0x19dc7fe8, "offset": 0x4acc}, {"addr": 0x486744, "value": 0x19dca7e8, "offset": 0x22cc}, {"addr": 0x48677c, "value": 0x19dc6fe8, "offset": 0x5acc}, {"addr": 0x4867bc, "value": 0x19dc2fe8, "offset": 0x9acc}]
    for addr in addrs:
        pointer = mouse.getAddressIntValue(addr['addr'])
        print(hex(pointer + addr['offset']))

next_pointer_scan()

# write_file(first_scan(start_addr, end_addr))
